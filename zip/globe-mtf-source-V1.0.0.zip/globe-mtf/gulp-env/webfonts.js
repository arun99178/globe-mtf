// ==========================================================================
// Gulp Babel :
// ==========================================================================

import { src, dest, series } from 'gulp';
import googleWebFonts from 'goog-webfont-dl';
import { pkgWebFont } from './theme.vars';
import log from 'fancy-log';

const getWebfonts = (done) => {
	Object.keys(pkgWebFont).forEach((fontLibName) => {
		return googleWebFonts(pkgWebFont[fontLibName]);
	});
	done();
};

module.exports = series(getWebfonts);
